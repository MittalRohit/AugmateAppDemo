package com.example.augmate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import android.app.Activity;
import android.app.ListActivity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView; 
import android.widget.AdapterView.OnItemClickListener;
import android.widget.SimpleAdapter;
import com.example.augmate.R;


import com.example.utils.*;

public class order extends Activity  {
	public Button message;
	public Button about;
	public ListView listView;
	
	private static final String TAG_INFORMATION = "information";
    private static final String TAG_USERNAME = "username";
    private static final String TAG_ORDER = "order";
    private static final String TAG_ADDRESS = "address";
    private static final String TAG_STATUS = "status";
    private static final String TAG_PRODUCTS = "products";
    
	
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final boolean customTitleSupported = requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
        setContentView(R.layout.order);
        
        // set title bar properties
        if ( customTitleSupported ) {
            getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.titlebar);
            }

        final TextView myTitleText = (TextView) findViewById(R.id.myTitle);
        if ( myTitleText != null ) {
            myTitleText.setText("Orders");
        }
             
        // initialize id
        listView = (ListView) findViewById(R.id.orderlist);
        listView.setItemsCanFocus(true);
        listView.setTextFilterEnabled(true);
        
        // get the infor from login activity
        Bundle extras = getIntent().getExtras();
        ArrayList<HashMap<String, String>> infor = (ArrayList<HashMap<String, String>>) extras.getSerializable(TAG_INFORMATION);
        String username = extras.getString(TAG_USERNAME);        
        
        		
        //initializing the list, only to show the orders for login user
        final ArrayList<HashMap<String, String>> fillMaps = new ArrayList<HashMap<String, String>>();       
        for(int i = 0; i < infor.size(); i++){
    		HashMap<String, String> map = infor.get(i);
    		if((map.get(TAG_USERNAME)).equals(username)){
    			fillMaps.add(map);
    		}
        }
        
        
        // show the list
        String[] from = new String[] { TAG_ORDER, TAG_ADDRESS, TAG_STATUS };
        int[] to = new int[] { R.id.orders, R.id.address, R.id.status };
        SimpleAdapter  adapter = new SimpleAdapter(this, fillMaps, R.layout.order, from, to);
        if (listView != null){
        	listView.setAdapter(adapter); 
		}
		else{
			listView.setVisibility(View.INVISIBLE);
		}
        
        // for future updating the local list
        //adapter.notifyDataSetChanged();
        
             
       // click one item, show the corresponding product list
       listView.setOnItemClickListener(new OnItemClickListener() {
 	      public void onItemClick(AdapterView<?> parent, View view,
 	          int position, long id) {  
     			 Intent intent = new Intent();
 	 	    	 intent.putExtra(TAG_INFORMATION,fillMaps); 
 	 	    	 intent.putExtra("index",Integer.toString(position)); 
 	 	    	 intent.setClass(view.getContext(), product.class);
 	 	    	 startActivity(intent);	
 	      }
 	    });
                  
	}
	
}