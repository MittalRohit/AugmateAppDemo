package com.example.augmate;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.example.augmate.R;
import com.example.utils.JSONParser;
import com.example.utils.JSONParser;
import java.util.ArrayList;
import java.util.HashMap;
 
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
 
import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract.Contacts;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;


public class login extends Activity {

	public EditText txtUserName;
	public EditText txtPassword;
	public Button btnLogin;
	public Button camera;
  
	// JSON Node tags
    private static final String TAG_INFORMATION = "information";
    private static final String TAG_USERNAME = "username";
    private static final String TAG_PASSWORD = "password";
    private static final String TAG_ORDER = "order";
    private static final String TAG_ADDRESS = "address";
    private static final String TAG_STATUS = "status";
    private static final String TAG_PRODUCTS = "products";
    
    // push json file to the phone, or save the file to the folder from transmission.
    private static String filename = "/mnt/sdcard/file/input.json";
	JSONArray information = null;
		
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final boolean customTitleSupported = requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
        setContentView(R.layout.activity_main);
     
        // set title bar properties
        if ( customTitleSupported ) {
            getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.titlebar);
            }

        final TextView myTitleText = (TextView) findViewById(R.id.myTitle);
        if ( myTitleText != null ) {
            myTitleText.setText("Augmate");    
        }
        
        
        // initialization 
        txtUserName=(EditText)this.findViewById(R.id.txtUname);
        txtPassword=(EditText)this.findViewById(R.id.txtPwd);       
        btnLogin=(Button)this.findViewById(R.id.btnLogin);
        camera = (Button)this.findViewById(R.id.camera);
        
        
        // call JSONparser
        JSONParser jParser = new JSONParser();               
        JSONObject json = jParser.getJSON(filename);
        final ArrayList<HashMap<String, String>> inforlist = new ArrayList<HashMap<String, String>>();
        
        try {
            // Getting Array of Contacts 
        	information = json.getJSONArray(TAG_INFORMATION);
 
            // looping through All Contacts
            for(int i = 0; i < information.length(); i++){
                JSONObject c = information.getJSONObject(i);
                
                // creating new HashMap
                HashMap<String, String> map = new HashMap<String, String>();
 
                // Storing each json item in variable               
                String username = c.getString(TAG_USERNAME);
                String password = c.getString(TAG_PASSWORD);
                String order = c.getString(TAG_ORDER);
                String address = c.getString(TAG_ADDRESS);
                String status = c.getString(TAG_STATUS);
                
                // adding each child node to HashMap key => value
                map.put(TAG_USERNAME, username);
                map.put(TAG_PASSWORD, password);
                map.put(TAG_ORDER, order);
                map.put(TAG_ADDRESS, address);
                map.put(TAG_STATUS, status);
               
                // products in JSON Object, the 2nd level
                JSONObject products = c.getJSONObject(TAG_PRODUCTS);             
                for(int j = 1; j <= products.length(); j++){
                	String id = TAG_ORDER+"-"+order+"-"+TAG_PRODUCTS+"-"+j;
                	String item = products.getString(id);
                	map.put(id, item);               	
                }     
                String product_number = Integer.toString(products.length());
                map.put(TAG_PRODUCTS,product_number);
 
                // adding HashList to ArrayList
                inforlist.add(map);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        
        // click the camera button to capture an image, for future face detection
        camera.setOnClickListener(new OnClickListener() {      	
            @Override
            public void onClick(View v) {       	
            	Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
            	 startActivityForResult(intent, 0); 
            }
            });  
        
        // check username and password, if matching, jump to oder page and show the order list      
        btnLogin.setOnClickListener(new OnClickListener() {      	
            @Override
            public void onClick(View v) { 
            	boolean flag = false;
            	String username = null;
            	for(int i = 0; i < inforlist.size(); i++){
            		HashMap<String, String> map = inforlist.get(i);
            	    if((txtUserName.getText().toString()).equals(map.get(TAG_USERNAME)) && (txtPassword.getText().toString()).equals(map.get(TAG_PASSWORD))){            	
         	   			flag = true;
         	   			username = txtUserName.getText().toString();
         	   			break;
        			}
            	}
            	            	
            	// check if the inputs are valid
            	if (flag == true){
            		Toast.makeText(login.this, "Login Successful",Toast.LENGTH_LONG).show();
            		Intent intent = new Intent();
            		intent.putExtra(TAG_INFORMATION,inforlist); 
            		intent.putExtra(TAG_USERNAME, username);
 	   				intent.setClass(v.getContext(), order.class);	   				
 	   				startActivity(intent);
            	}
            	else{
            		Toast.makeText(login.this, "Invalid Login",Toast.LENGTH_LONG).show();
            	}
            }
            });  
        	
        
    }
} 