package com.example.augmate;

import java.util.ArrayList;
import java.util.HashMap;

import com.example.augmate.R;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class product extends Activity {
	
	public Button map;
	public ListView productlist;
	public Button scanner;
	public Button ok;
	
	private static final String TAG_INFORMATION = "information";
	private static final String TAG_ORDER = "order";
	private static final String TAG_PRODUCTS = "products";
	private static final String TAG_STATUS = "status";
	
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final boolean customTitleSupported = requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
        setContentView(R.layout.product);
        
        // set title bar properties
        if ( customTitleSupported ) {
            getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.titlebar);
            }

        final TextView myTitleText = (TextView) findViewById(R.id.myTitle);
        if ( myTitleText != null ) {
            myTitleText.setText("Products");          
        }
               
        productlist = (ListView) findViewById(R.id.productlist);
        scanner = (Button)this.findViewById(R.id.scanner);
        ok = (Button)this.findViewById(R.id.ok);
        
        // for future map images
        //map = (Button)this.findViewById(R.id.map);
        
        
        // get the information from order activity
        Bundle extras = getIntent().getExtras();
        final ArrayList<HashMap<String, String>> orders = (ArrayList<HashMap<String, String>>) extras.getSerializable(TAG_INFORMATION);
        String pos = extras.getString("index");
        int position = Integer.parseInt(pos);
        
        
        // get the product list for current order
        final HashMap<String, String> map = orders.get(position );
        String order_number = map.get(TAG_ORDER);
        String product_number = map.get(TAG_PRODUCTS);
        int length = Integer.parseInt(product_number);
        String[] values = new String[length];
        for (int i = 1; i<= length; i++){
        	String id = TAG_ORDER+"-"+order_number+"-"+TAG_PRODUCTS+"-"+i;
        	values[i-1] = map.get(id);
        }       
        
        // show the order list
        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, android.R.id.text1, values);      
        productlist.setAdapter(adapter);       
              
        // call the scanner for decoding QR code (need to install ZXing scanner to the phone.)
        scanner.setOnClickListener(new OnClickListener() {      	
            @Override
            public void onClick(View v) {       	
            	Intent intent = new Intent("com.google.zxing.client.android.SCAN");
                intent.setPackage("com.google.zxing.client.android");
                intent.putExtra("SCAN_MODE", "QR_CODE_MODE");
            	 startActivityForResult(intent, 0); 
            }
            });  
       
       // open the map
       /*
       map.setOnClickListener(new OnClickListener() {      	
           @Override
           public void onClick(View v) {       	
        	   Intent intent = new Intent();
        	   startActivity(intent);
           }
           });  
           */    
        
        
        // send updated order status to CMS
        /*
        ok.setOnClickListener(new OnClickListener() {      	
            @Override
            public void onClick(View v) {       	
            	String status = map.get(TAG_STATUS);
            	if (status != "done"){
            		map.put(TAG_STATUS, "done");
            	}
            	 orders.add(map);
            	 Intent intent = new Intent();
	 	    	 intent.putExtra("visit", "update"); 
	 	    	 intent.setClass(v.getContext(), order.class);
	 	    	 startActivity(intent);	            	
            }
            });  
            */
	}
	
	
	// show the decoded QR code result
	public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        if (requestCode == 0) {
            if (resultCode == RESULT_OK) {
                String contents = intent.getStringExtra("SCAN_RESULT");
                String format = intent.getStringExtra("SCAN_RESULT_FORMAT");
                
                // Handle successful scan, showing product picked.
                Toast.makeText(product.this, contents,Toast.LENGTH_LONG).show();               
            }
        }
    }
	
	
}